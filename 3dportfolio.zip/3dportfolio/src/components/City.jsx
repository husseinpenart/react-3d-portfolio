import React from 'react'
import { MyWorkSpace } from './Models/CityEnviroment'

const City = () => {
  return (
    <div>
        <MyWorkSpace />
    </div>
  )
}

export default City