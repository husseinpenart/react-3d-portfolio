import React from 'react'

const Forms = () => {
  return (
    <div>
       <div className='text-white'>
       <h1 className='text-3xl mt-5 mb-5 font-bold'>سلام حسین اسدی هستم</h1>
        <h3 className='text-center text-xl mt-10 mb-5'>software developer || FullStack Developer</h3>
        <p className='text-justify leading-10 text-sm'>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ، و با استفاده از طراحان گرافیک است، چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است، و برای شرایط فعلی تکنولوژی مورد نیاز، و کاربردهای متنوع</p>
        <br />
        <span className='text-center mb-3 mt-10 text-lg'>با من در تماس باشید</span>
        <br /><br />
       </div>
        <form >
            <div className='flex flex-wrap gap-3'>
                <input type="text"  className='w-full h-10 border-2 outline-none border-red-200 rounded-lg mt-5' placeholder='نام و نام خانوادگی'/>
                <input type="text"  className='w-full h-10 border-2 outline-none border-red-200 rounded-lg mt-5' placeholder='شماره تماس'/>
                <input type="text"  className='w-full h-10 border-2 outline-none border-red-200 rounded-lg mt-5' placeholder='ایمیل'/>
               <textarea cols="60" rows={10} className='w-full border-2 outline-none border-red-200 rounded-lg mt-5' placeholder='پیغام شما'></textarea>
            </div>
        </form>
    </div>
  )
}

export default Forms