import { useState } from 'react'
import { CiMenuFries } from "react-icons/ci";

const Navbar = () => {
    const [mobile, setMobile] = useState(false)
    const responsive = () => {
        setMobile(!mobile)
    }

    return (
        <div>
            <nav className='bg-white border-gray-300 dark:bg-gray-900'>
                <div className='max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4'>
                    <a href="/home" className='flex items-center space-x-3 rtl:space-x-reverse'>
                        <img src="https://logowik.com/content/uploads/images/adobe-portfolio8664.jpg" className='h-8' alt="" />
                        <span className='self-center text-2xl font-semibold whitespace-nowrap'>Portfolio</span>
                    </a>
                    <button type='button' className='inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-200 ' onClick={responsive}>
                        <span className='sr-only'>منو</span>
                        <CiMenuFries className='text-3xl font-extrabold' />
                    </button>
                    {mobile ? <div className=' w-full md:block md:w-auto'>
                        <ul className='flex flex-col gap-5 md:p-0 mt-4 border border-gray-200 rounded-lg bg-gray-500 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 md:bg-white'>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>صفحه اصلی</a></li>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>خانه</a></li>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>درباره من</a></li>
                        </ul>
                    </div> : <div className='hidden w-full md:block md:w-auto'>
                        <ul className='flex flex-col gap-5 md:p-0 mt-4 border border-gray-200 rounded-lg bg-gray-50 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 md:bg-white'>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>صفحه اصلی</a></li>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>خانه</a></li>
                            <li><a href="" className='block py-2 px-3 text-white bg-lue-700 rounded md:bg-transparent md:text-indigo-700 md:p-0 '>درباره من</a></li>
                        </ul>
                    </div>}
                </div>
            </nav >
        </div >
    )
}

export default Navbar