import { useState , useEffect } from "react";
import axios from 'axios'
import Data from './Data.json'


const ProjectSection  =()=>{
const [projects , setProjects] =useState([])
useEffect(()=>{
    const fetchData = async()=>{
     try {
        const res = await axios.get(Data)
        setProjects(res.config.url)
     } catch (error) {
        console.log(error)
     }
    }
    fetchData()
} , [])
    return(
  <div className="flex flex-wrap gap-5 justify-center items-center m-5" dir="rtl">
      {projects.map((e,i)=>{
        return(
            <div className="relative flex flex-col mt-6 text-gray-700 bg-white shadow-md bg-clip-border rounded-xl w-96 mb-5" key={i}>
                <div className="relative h-56 mx-4 -mt-6 overflow-hidden text-white shadow-lg bg-clip-border rounded-xl">
                    <img src={e.mainImg} alt="" />
                </div>
                <div className="p-6">
                    <h5 className="block mb-2 text-xl font-semibold leading-snug tracking-normal text-blue-950">
                        {e.title}
                    </h5>
                    <p className="block text-base font-light leading-relaxed text-inherit">{e.properties}</p>
                </div>
                <div className="p-6 pt-0">
                    <button className="text-center outline-dotted p-3 rounded-lg shadow-md">ادامه</button>
                </div>
            </div>
        )
      })}
  </div>
    )
}

export default ProjectSection