import React from 'react'
import City from '../components/City'

const Homepage = () => {
  return (
    <div >
        <City />
    </div>
  )
}

export default Homepage